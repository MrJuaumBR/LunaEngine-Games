# Naves
[🇺🇸 English](#en-us)

[🇧🇷 Brazillian Portuguese](#pt-br)

[Credits/Créditos](#credits)

## En-US
**Naves** or **Spaceship** is game developed in Python with [LunaEngine](https://github.com/MrJuaumBR/LunaEngine) for 2 reasons, the first one, a more complex and well built example for LunaEngine module, for those who wanna learn how to use it, the second reason is for a school presentation, is basically a school subject that we have to show some coding abilitties y'know.

## Pt-BR
**Naves** ou **Spaceship** é um jogo desenvolvido em Python com [LunaEngine](https://github.com/MrJuaumBR/LunaEngine) por dois motivos: o primeiro é um exemplo mais complexo e bem construído do módulo LunaEngine, para aqueles que querem aprender a usá-lo; o segundo motivo é para uma apresentação escolar, já que é uma disciplina na qual precisamos demonstrar algumas habilidades de programação.

## Credits
Thanks for those who helped developing this project.

- @MrJuaumBR (Coding)
- [LunaEngine](https://github.com/MrJuaumBR/LunaEngine) (Engine)
- Vitor/Tretabe (Arts)