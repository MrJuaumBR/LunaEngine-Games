from lunaengine.core import LunaEngine, Scene
from lunaengine.ui import *
from lunaengine.backend import OpenGLRenderer

from argparse import ArgumentParser
from pathlib import Path
import os, random, sys

COLORS = [ # 7 colors in Tuples = ('red', ...)
    ('RED', (200, 50, 50)), # c83232
    ('GREEN', (50, 200, 50)), # 32c832
    ('BLUE', (50, 50, 200)), # 3232c8
    ('YELLOW', (200, 200, 50)), # c8c832
    ('PINK', (200, 50, 200)),  # c832c8
    ('CYAN', (50, 200, 200)), # 32c8c8
    ('ORANGE', (200, 100, 50)) # c86432
]

RANDOMNESS_SEED = 2026



class MainMenu(Scene):
    def __init__(self, engine:LunaEngine):
        super().__init__(engine)
        
        self.setup_ui()
        
    def setup_ui(self):
        self.add_ui_element(TextLabel(self.engine.width//2, 100, 'Dye Sorter', 76, pivot=(0.5,  0)))
        
    
def main():
    args = sys.argv[1:]
    parser = ArgumentParser()
    parser.add_argument('-f', '--fullscreen', action='store_true')
    parser.add_argument('-d', '--debug', action='store_true')
    
    args = parser.parse_args(args)
    
    engine = LunaEngine('Dye Sorter', 1280, 720, debug=args.debug, fullscreen=args.fullscreen)
    
    engine.atlas.add_folder('root', Path(os.path.abspath(os.path.dirname(__file__))))
    engine.atlas.add_texture('icon', engine.atlas.get_item('root').path / 'icon.png')
    engine.atlas.add_texture('flask', engine.atlas.get_item('root').path / 'flask.png')
    
    engine.set_icon(str(engine.atlas.get_item('icon').path))
    
    engine.set_global_theme(ThemeType.CLOUDS, False)
    
    engine.add_scene('main', MainMenu)
    engine.set_scene('main')
    
    engine.run()
    
if __name__ == '__main__':
    main()